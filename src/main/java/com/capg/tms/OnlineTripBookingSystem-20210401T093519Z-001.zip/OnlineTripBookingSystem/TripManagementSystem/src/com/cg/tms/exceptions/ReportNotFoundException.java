package com.cg.tms.exceptions;

public class ReportNotFoundException extends Exception {

}
