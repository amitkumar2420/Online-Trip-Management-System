package com.cg.tms.entities;

public class Bus {

	
	private int busId;
	private  String busType;
	private  String busNumber;
	private int capacity;
	private Travels travel;
	
	
	
	
}
