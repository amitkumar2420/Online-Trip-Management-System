package com.cg.tms.entities;

public class Travels {
	
	private int travelsId;
	private String travelsName;
	private String  agentName;
	private String  address;
	private String  contact;
	
	
	
	
	
	
 
}
