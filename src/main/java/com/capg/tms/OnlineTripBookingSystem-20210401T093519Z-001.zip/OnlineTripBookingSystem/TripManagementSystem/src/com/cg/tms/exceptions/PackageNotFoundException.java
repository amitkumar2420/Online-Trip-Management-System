package com.cg.tms.exceptions;

public class PackageNotFoundException extends Exception {

}
