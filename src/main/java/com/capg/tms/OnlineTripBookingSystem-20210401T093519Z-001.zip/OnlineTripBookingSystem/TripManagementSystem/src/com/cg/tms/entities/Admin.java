package com.cg.tms.entities;

public class Admin {
	
	
	private int  adminId;
	private String adminName;
	private  String password;
	private String email;
	private  String mobile;
	
	
	
	

}
