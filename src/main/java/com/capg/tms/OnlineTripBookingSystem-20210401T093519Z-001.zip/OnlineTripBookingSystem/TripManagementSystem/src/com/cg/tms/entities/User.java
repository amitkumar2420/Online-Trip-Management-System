package com.cg.tms.entities;

public class User {

	private int userId;
	private String userType;
	private String password;
	

}
