package com.cg.tms.entities;

import java.time.LocalDate;

public class Booking {
	
	private int bookingId;
	private String bookingType;
	private String description;
	private String bookingTitle;
	private  LocalDate bookingDate;
	private Package pack;
	private  int userId;
	
	

}
