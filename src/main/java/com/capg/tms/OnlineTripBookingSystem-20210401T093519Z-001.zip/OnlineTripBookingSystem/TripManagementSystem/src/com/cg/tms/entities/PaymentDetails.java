package com.cg.tms.entities;

public class PaymentDetails {
	
	private  int paymentId;
	private  String paymentMode;
	private  String bankName;
	private  long  cardNo;
	private double   netAmount;
	private  String  paymentStatus;
	private  int userId;
	

}
