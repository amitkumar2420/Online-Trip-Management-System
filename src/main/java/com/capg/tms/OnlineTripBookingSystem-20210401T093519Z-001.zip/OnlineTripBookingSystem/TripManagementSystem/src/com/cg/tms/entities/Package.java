package com.cg.tms.entities;

public class Package {
	
	private int packageId;
	private String packageName;
	private String packageDescription;
	private String packageType;
	private double packageCost;
	private  PaymentDetails  payment;
	private TicketDetails ticket;
	private Hotel hotel;
	
	

}
