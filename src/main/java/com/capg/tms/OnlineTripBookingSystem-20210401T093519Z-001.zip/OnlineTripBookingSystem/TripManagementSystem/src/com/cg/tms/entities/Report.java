package com.cg.tms.entities;

public class Report {
	
	private int reportId;
	private String reportName;
	private String reportType;
	
	
	

}
