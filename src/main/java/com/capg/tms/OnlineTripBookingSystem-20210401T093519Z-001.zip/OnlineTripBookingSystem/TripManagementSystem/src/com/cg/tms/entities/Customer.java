package com.cg.tms.entities;

public class Customer {

	private  int customerId;
	private String customerName;
	private String  customerPassword;
	private String address;
	private String mobileNo;
	private String email;
	
	
	
	
}
